# OCR SaaS MVP Implementation Guide

## MVP Scope & Features

### Core Features
- User registration/authentication
- Image upload and OCR processing
- Basic subscription management (Free/Paid tiers)
- Usage tracking and limits
- Simple dashboard
- API endpoints for developers

### Tech Stack
- **Backend**: Python + FastAPI
- **Frontend**: React.js + Vite
- **Database**: PostgreSQL
- **Authentication**: JWT
- **Payments**: Stripe
- **OCR**: EasyOCR
- **Deployment**: Railway/Render + Vercel

## Project Structure

```
ocr-saas/
├── backend/
│   ├── app/
│   │   ├── __init__.py
│   │   ├── main.py
│   │   ├── models/
│   │   ├── routers/
│   │   ├── services/
│   │   ├── utils/
│   │   └── database.py
│   ├── requirements.txt
│   └── Dockerfile
├── frontend/
│   ├── src/
│   │   ├── components/
│   │   ├── pages/
│   │   ├── services/
│   │   └── utils/
│   ├── package.json
│   └── vite.config.js
└── docker-compose.yml
```

## Backend Implementation

### 1. Setup & Dependencies

**requirements.txt**
```txt
fastapi==0.104.1
uvicorn==0.24.0
sqlalchemy==2.0.23
psycopg2-binary==2.9.9
python-jose[cryptography]==3.3.0
passlib[bcrypt]==1.7.4
python-multipart==0.0.6
stripe==7.7.0
easyocr==1.7.0
pillow==10.1.0
python-dotenv==1.0.0
alembic==1.12.1
redis==5.0.1
celery==5.3.4
```

### 2. Database Models

**app/models/user.py**
```python
from sqlalchemy import Column, Integer, String, DateTime, Boolean, Float
from sqlalchemy.ext.declarative import declarative_base
from datetime import datetime

Base = declarative_base()

class User(Base):
    __tablename__ = "users"
    
    id = Column(Integer, primary_key=True, index=True)
    email = Column(String, unique=True, index=True)
    hashed_password = Column(String)
    is_active = Column(Boolean, default=True)
    subscription_tier = Column(String, default="free")  # free, starter, pro
    monthly_usage = Column(Integer, default=0)
    usage_reset_date = Column(DateTime, default=datetime.utcnow)
    stripe_customer_id = Column(String, nullable=True)
    api_key = Column(String, unique=True, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

class ProcessingJob(Base):
    __tablename__ = "processing_jobs"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, index=True)
    filename = Column(String)
    status = Column(String, default="pending")  # pending, processing, completed, failed
    extracted_text = Column(String, nullable=True)
    confidence_score = Column(Float, nullable=True)
    processing_time = Column(Float, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    completed_at = Column(DateTime, nullable=True)
```

### 3. Core FastAPI Application

**app/main.py**
```python
from fastapi import FastAPI, HTTPException, Depends, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from sqlalchemy.orm import Session
import uvicorn
import os
from datetime import datetime, timedelta
import secrets

from .database import get_db, engine
from .models.user import Base, User, ProcessingJob
from .services.auth import AuthService
from .services.ocr import OCRService
from .services.subscription import SubscriptionService
from .routers import auth, ocr, subscription

# Create tables
Base.metadata.create_all(bind=engine)

app = FastAPI(title="OCR SaaS API", version="1.0.0")

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000"],  # React dev server
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include routers
app.include_router(auth.router, prefix="/api/auth", tags=["auth"])
app.include_router(ocr.router, prefix="/api/ocr", tags=["ocr"])
app.include_router(subscription.router, prefix="/api/subscription", tags=["subscription"])

@app.get("/")
def read_root():
    return {"message": "OCR SaaS API is running"}

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)
```

### 4. Authentication Service

**app/services/auth.py**
```python
from passlib.context import CryptContext
from jose import JWTError, jwt
from datetime import datetime, timedelta
from fastapi import HTTPException, status
import secrets
import os

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
SECRET_KEY = os.getenv("SECRET_KEY", "your-secret-key-here")
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 30

class AuthService:
    @staticmethod
    def verify_password(plain_password, hashed_password):
        return pwd_context.verify(plain_password, hashed_password)

    @staticmethod
    def get_password_hash(password):
        return pwd_context.hash(password)

    @staticmethod
    def create_access_token(data: dict, expires_delta: timedelta = None):
        to_encode = data.copy()
        if expires_delta:
            expire = datetime.utcnow() + expires_delta
        else:
            expire = datetime.utcnow() + timedelta(minutes=15)
        to_encode.update({"exp": expire})
        encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
        return encoded_jwt

    @staticmethod
    def verify_token(token: str):
        try:
            payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
            email: str = payload.get("sub")
            if email is None:
                raise HTTPException(status_code=401, detail="Invalid token")
            return email
        except JWTError:
            raise HTTPException(status_code=401, detail="Invalid token")

    @staticmethod
    def generate_api_key():
        return secrets.token_urlsafe(32)
```

### 5. OCR Service

**app/services/ocr.py**
```python
import easyocr
import numpy as np
from PIL import Image
import io
import time
from typing import Dict, Any

class OCRService:
    def __init__(self):
        self.reader = easyocr.Reader(['en'])
    
    def preprocess_image(self, image_bytes: bytes) -> np.ndarray:
        """Preprocess image for better OCR results"""
        image = Image.open(io.BytesIO(image_bytes))
        
        # Convert to RGB if necessary
        if image.mode != 'RGB':
            image = image.convert('RGB')
        
        # Resize if too large (max 2000px width)
        if image.width > 2000:
            ratio = 2000 / image.width
            new_height = int(image.height * ratio)
            image = image.resize((2000, new_height), Image.Resampling.LANCZOS)
        
        return np.array(image)
    
    def extract_text(self, image_bytes: bytes) -> Dict[str, Any]:
        """Extract text from image using EasyOCR"""
        start_time = time.time()
        
        try:
            # Preprocess image
            image_array = self.preprocess_image(image_bytes)
            
            # Perform OCR
            results = self.reader.readtext(image_array)
            
            # Process results
            extracted_text = ""
            total_confidence = 0
            text_blocks = []
            
            for (bbox, text, confidence) in results:
                extracted_text += text + " "
                total_confidence += confidence
                text_blocks.append({
                    "text": text,
                    "confidence": confidence,
                    "bbox": bbox
                })
            
            avg_confidence = total_confidence / len(results) if results else 0
            processing_time = time.time() - start_time
            
            return {
                "text": extracted_text.strip(),
                "confidence": avg_confidence,
                "processing_time": processing_time,
                "text_blocks": text_blocks,
                "status": "success"
            }
            
        except Exception as e:
            return {
                "text": "",
                "confidence": 0,
                "processing_time": time.time() - start_time,
                "text_blocks": [],
                "status": "error",
                "error": str(e)
            }

# Global OCR service instance
ocr_service = OCRService()
```

### 6. Subscription Service

**app/services/subscription.py**
```python
import stripe
import os
from datetime import datetime, timedelta
from sqlalchemy.orm import Session
from ..models.user import User

stripe.api_key = os.getenv("STRIPE_SECRET_KEY")

class SubscriptionService:
    USAGE_LIMITS = {
        "free": 100,
        "starter": 1000,
        "pro": 10000
    }
    
    STRIPE_PRICES = {
        "starter": os.getenv("STRIPE_STARTER_PRICE_ID"),
        "pro": os.getenv("STRIPE_PRO_PRICE_ID")
    }
    
    @staticmethod
    def check_usage_limit(user: User) -> bool:
        """Check if user has exceeded their monthly limit"""
        limit = SubscriptionService.USAGE_LIMITS.get(user.subscription_tier, 100)
        return user.monthly_usage < limit
    
    @staticmethod
    def increment_usage(user: User, db: Session):
        """Increment user's monthly usage"""
        # Reset usage if it's a new month
        if user.usage_reset_date.month != datetime.utcnow().month:
            user.monthly_usage = 0
            user.usage_reset_date = datetime.utcnow()
        
        user.monthly_usage += 1
        db.commit()
    
    @staticmethod
    def create_checkout_session(user: User, tier: str):
        """Create Stripe checkout session"""
        try:
            checkout_session = stripe.checkout.Session.create(
                customer=user.stripe_customer_id,
                payment_method_types=['card'],
                line_items=[{
                    'price': SubscriptionService.STRIPE_PRICES[tier],
                    'quantity': 1,
                }],
                mode='subscription',
                success_url=f"{os.getenv('FRONTEND_URL')}/dashboard?success=true",
                cancel_url=f"{os.getenv('FRONTEND_URL')}/pricing?canceled=true",
                metadata={
                    'user_id': user.id,
                    'tier': tier
                }
            )
            return checkout_session
        except Exception as e:
            raise Exception(f"Error creating checkout session: {str(e)}")
```

### 7. API Routes

**app/routers/auth.py**
```python
from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from sqlalchemy.orm import Session
from pydantic import BaseModel
import stripe

from ..database import get_db
from ..models.user import User
from ..services.auth import AuthService

router = APIRouter()
security = HTTPBearer()

class UserCreate(BaseModel):
    email: str
    password: str

class UserLogin(BaseModel):
    email: str
    password: str

@router.post("/register")
def register(user: UserCreate, db: Session = Depends(get_db)):
    # Check if user exists
    db_user = db.query(User).filter(User.email == user.email).first()
    if db_user:
        raise HTTPException(status_code=400, detail="Email already registered")
    
    # Create Stripe customer
    stripe_customer = stripe.Customer.create(email=user.email)
    
    # Create user
    hashed_password = AuthService.get_password_hash(user.password)
    api_key = AuthService.generate_api_key()
    
    db_user = User(
        email=user.email,
        hashed_password=hashed_password,
        stripe_customer_id=stripe_customer.id,
        api_key=api_key
    )
    db.add(db_user)
    db.commit()
    db.refresh(db_user)
    
    # Create access token
    access_token = AuthService.create_access_token(data={"sub": user.email})
    
    return {
        "access_token": access_token,
        "token_type": "bearer",
        "user": {
            "id": db_user.id,
            "email": db_user.email,
            "subscription_tier": db_user.subscription_tier,
            "api_key": db_user.api_key
        }
    }

@router.post("/login")
def login(user: UserLogin, db: Session = Depends(get_db)):
    db_user = db.query(User).filter(User.email == user.email).first()
    if not db_user or not AuthService.verify_password(user.password, db_user.hashed_password):
        raise HTTPException(status_code=401, detail="Invalid credentials")
    
    access_token = AuthService.create_access_token(data={"sub": user.email})
    
    return {
        "access_token": access_token,
        "token_type": "bearer",
        "user": {
            "id": db_user.id,
            "email": db_user.email,
            "subscription_tier": db_user.subscription_tier,
            "monthly_usage": db_user.monthly_usage,
            "api_key": db_user.api_key
        }
    }

def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(security), db: Session = Depends(get_db)):
    email = AuthService.verify_token(credentials.credentials)
    user = db.query(User).filter(User.email == email).first()
    if user is None:
        raise HTTPException(status_code=404, detail="User not found")
    return user
```

**app/routers/ocr.py**
```python
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File
from sqlalchemy.orm import Session
from datetime import datetime

from ..database import get_db
from ..models.user import User, ProcessingJob
from ..services.ocr import ocr_service
from ..services.subscription import SubscriptionService
from ..routers.auth import get_current_user

router = APIRouter()

@router.post("/process")
async def process_image(
    file: UploadFile = File(...),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    # Check usage limit
    if not SubscriptionService.check_usage_limit(current_user):
        raise HTTPException(status_code=429, detail="Monthly usage limit exceeded")
    
    # Validate file
    if not file.content_type.startswith('image/'):
        raise HTTPException(status_code=400, detail="File must be an image")
    
    # Read file
    image_bytes = await file.read()
    
    # Create processing job
    job = ProcessingJob(
        user_id=current_user.id,
        filename=file.filename,
        status="processing"
    )
    db.add(job)
    db.commit()
    db.refresh(job)
    
    try:
        # Process image
        result = ocr_service.extract_text(image_bytes)
        
        # Update job
        job.status = "completed" if result["status"] == "success" else "failed"
        job.extracted_text = result["text"]
        job.confidence_score = result["confidence"]
        job.processing_time = result["processing_time"]
        job.completed_at = datetime.utcnow()
        
        # Increment usage
        SubscriptionService.increment_usage(current_user, db)
        
        db.commit()
        
        return {
            "job_id": job.id,
            "status": job.status,
            "extracted_text": job.extracted_text,
            "confidence_score": job.confidence_score,
            "processing_time": job.processing_time
        }
        
    except Exception as e:
        job.status = "failed"
        db.commit()
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/jobs")
def get_jobs(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    jobs = db.query(ProcessingJob).filter(ProcessingJob.user_id == current_user.id).order_by(ProcessingJob.created_at.desc()).limit(50).all()
    return {"jobs": jobs}

@router.get("/usage")
def get_usage(current_user: User = Depends(get_current_user)):
    limit = SubscriptionService.USAGE_LIMITS.get(current_user.subscription_tier, 100)
    return {
        "current_usage": current_user.monthly_usage,
        "limit": limit,
        "tier": current_user.subscription_tier,
        "usage_percentage": (current_user.monthly_usage / limit) * 100
    }
```

## Frontend Implementation

### 1. Setup React Project

```bash
npm create vite@latest ocr-frontend -- --template react
cd ocr-frontend
npm install axios react-router-dom @headlessui/react @heroicons/react
```

### 2. Main App Component

**src/App.jsx**
```jsx
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import { AuthProvider } from './contexts/AuthContext'
import Header from './components/Header'
import Home from './pages/Home'
import Login from './pages/Login'
import Register from './pages/Register'
import Dashboard from './pages/Dashboard'
import Pricing from './pages/Pricing'
import PrivateRoute from './components/PrivateRoute'

function App() {
  return (
    <AuthProvider>
      <Router>
        <div className="min-h-screen bg-gray-50">
          <Header />
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/login" element={<Login />} />
            <Route path="/register" element={<Register />} />
            <Route path="/pricing" element={<Pricing />} />
            <Route 
              path="/dashboard" 
              element={
                <PrivateRoute>
                  <Dashboard />
                </PrivateRoute>
              } 
            />
          </Routes>
        </div>
      </Router>
    </AuthProvider>
  )
}

export default App
```

### 3. Auth Context

**src/contexts/AuthContext.jsx**
```jsx
import { createContext, useContext, useState, useEffect } from 'react'
import api from '../services/api'

const AuthContext = createContext()

export function useAuth() {
  return useContext(AuthContext)
}

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const token = localStorage.getItem('token')
    if (token) {
      api.defaults.headers.common['Authorization'] = `Bearer ${token}`
      // Verify token validity here if needed
    }
    setLoading(false)
  }, [])

  const login = async (email, password) => {
    const response = await api.post('/auth/login', { email, password })
    const { access_token, user: userData } = response.data
    
    localStorage.setItem('token', access_token)
    api.defaults.headers.common['Authorization'] = `Bearer ${access_token}`
    setUser(userData)
    
    return userData
  }

  const register = async (email, password) => {
    const response = await api.post('/auth/register', { email, password })
    const { access_token, user: userData } = response.data
    
    localStorage.setItem('token', access_token)
    api.defaults.headers.common['Authorization'] = `Bearer ${access_token}`
    setUser(userData)
    
    return userData
  }

  const logout = () => {
    localStorage.removeItem('token')
    delete api.defaults.headers.common['Authorization']
    setUser(null)
  }

  const value = {
    user,
    login,
    register,
    logout,
    loading
  }

  return (
    <AuthContext.Provider value={value}>
      {!loading && children}
    </AuthContext.Provider>
  )
}
```

### 4. Dashboard Component

**src/pages/Dashboard.jsx**
```jsx
import { useState, useEffect } from 'react'
import { useAuth } from '../contexts/AuthContext'
import api from '../services/api'
import ImageUpload from '../components/ImageUpload'
import UsageStats from '../components/UsageStats'
import JobHistory from '../components/JobHistory'

function Dashboard() {
  const { user } = useAuth()
  const [usage, setUsage] = useState(null)
  const [jobs, setJobs] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchData()
  }, [])

  const fetchData = async () => {
    try {
      const [usageRes, jobsRes] = await Promise.all([
        api.get('/ocr/usage'),
        api.get('/ocr/jobs')
      ])
      setUsage(usageRes.data)
      setJobs(jobsRes.data.jobs)
    } catch (error) {
      console.error('Error fetching data:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleProcessComplete = (newJob) => {
    setJobs(prev => [newJob, ...prev])
    fetchData() // Refresh usage stats
  }

  if (loading) {
    return <div className="flex justify-center items-center h-64">Loading...</div>
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Dashboard</h1>
        <p className="text-gray-600">Welcome back, {user?.email}</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <ImageUpload onProcessComplete={handleProcessComplete} />
          <div className="mt-8">
            <JobHistory jobs={jobs} />
          </div>
        </div>
        <div>
          <UsageStats usage={usage} />
        </div>
      </div>
    </div>
  )
}

export default Dashboard
```

### 5. Image Upload Component

**src/components/ImageUpload.jsx**
```jsx
import { useState, useCallback } from 'react'
import { useDropzone } from 'react-dropzone'
import api from '../services/api'

function ImageUpload({ onProcessComplete }) {
  const [processing, setProcessing] = useState(false)
  const [result, setResult] = useState(null)
  const [error, setError] = useState(null)

  const onDrop = useCallback(async (acceptedFiles) => {
    const file = acceptedFiles[0]
    if (!file) return

    setProcessing(true)
    setError(null)
    setResult(null)

    try {
      const formData = new FormData()
      formData.append('file', file)

      const response = await api.post('/ocr/process', formData, {
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      })

      setResult(response.data)
      onProcessComplete?.(response.data)
    } catch (err) {
      setError(err.response?.data?.detail || 'Processing failed')
    } finally {
      setProcessing(false)
    }
  }, [onProcessComplete])

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'image/*': ['.png', '.jpg', '.jpeg', '.gif', '.bmp']
    },
    maxFiles: 1,
    disabled: processing
  })

  return (
    <div className="bg-white rounded-lg shadow p-6">
      <h2 className="text-xl font-semibold mb-4">Process Image</h2>
      
      <div
        {...getRootProps()}
        className={`border-2 border-dashed rounded-lg p-8 text-center cursor-pointer transition-colors ${
          isDragActive 
            ? 'border-blue-400 bg-blue-50' 
            : 'border-gray-300 hover:border-gray-400'
        } ${processing ? 'opacity-50 cursor-not-allowed' : ''}`}
      >
        <input {...getInputProps()} />
        {processing ? (
          <div>
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-2"></div>
            <p>Processing image...</p>
          </div>
        ) : (
          <div>
            <p className="text-lg mb-2">
              {isDragActive 
                ? 'Drop the image here...' 
                : 'Drag & drop an image here, or click to select'
              }
            </p>
            <p className="text-sm text-gray-500">
              Supports: PNG, JPG, JPEG, GIF, BMP
            </p>
          </div>
        )}
      </div>

      {error && (
        <div className="mt-4 p-4 bg-red-50 border border-red-200 rounded-md">
          <p className="text-red-600">{error}</p>
        </div>
      )}

      {result && (
        <div className="mt-4 p-4 bg-green-50 border border-green-200 rounded-md">
          <h3 className="font-semibold text-green-800 mb-2">Extraction Complete</h3>
          <div className="space-y-2 text-sm">
            <p><span className="font-medium">Confidence:</span> {(result.confidence_score * 100).toFixed(1)}%</p>
            <p><span className="font-medium">Processing Time:</span> {result.processing_time.toFixed(2)}s</p>
            <div>
              <span className="font-medium">Extracted Text:</span>
              <div className="mt-1 p-2 bg-white border rounded">
                {result.extracted_text || 'No text found'}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

export default ImageUpload
```

## Deployment Guide

### 1. Environment Variables

**Backend (.env)**
```
DATABASE_URL=postgresql://username:password@localhost/ocr_saas
SECRET_KEY=your-super-secret-key-here
STRIPE_SECRET_KEY=sk_test_...
STRIPE_STARTER_PRICE_ID=price_...
STRIPE_PRO_PRICE_ID=price_...
FRONTEND_URL=http://localhost:3000
```

**Frontend (.env)**
```
VITE_API_URL=http://localhost:8000/api
VITE_STRIPE_PUBLISHABLE_KEY=pk_test_...
```

### 2. Database Setup

```bash
# Install PostgreSQL locally or use a cloud service
createdb ocr_saas

# Run migrations (if using Alembic)
alembic upgrade head
```

### 3. Local Development

**Backend:**
```bash
cd backend
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000
```

**Frontend:**
```bash
cd frontend
npm install
npm run dev
```

### 4. Production Deployment

**Option 1: Railway (Recommended for MVP)**
1. Push code to GitHub
2. Connect Railway to your repository
3. Add environment variables
4. Deploy automatically

**Option 2: Render + Vercel**
- Backend on Render
- Frontend on Vercel
- PostgreSQL on Render or separate service

### 5. Stripe Setup

1. Create Stripe account
2. Create products and prices
3. Set up webhook endpoints
4. Configure environment variables

## Testing Strategy

### Backend Tests
```python
# test_main.py
import pytest
from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

def test_register_user():
    response = client.post("/api/auth/register", json={
        "email": "test@example.com",
        "password": "testpass123"
    })
    assert response.status_code == 200
    assert "access_token" in response.json()
```

### Frontend Tests
```javascript
// App.test.jsx
import { render, screen } from '@testing-library/react'
import App from './App'

test('renders home page', () => {
  render(<App />)
  const linkElement = screen.getByText(/OCR SaaS/i)
  expect(linkElement).toBeInTheDocument()
})
```

## Next Steps After MVP

1. **Add webhook system** for real-time notifications
2. **Implement batch processing** for multiple images
3. **Add more OCR engines** (Tesseract fallback)
4. **Create mobile app** with React Native
5. **Add analytics dashboard** for usage insights
6. **Implement team/organization features**
7. **Add API documentation** with Swagger UI
8. **Set up monitoring** and alerting

This MVP provides a solid foundation that you can build upon while generating revenue from day one!