import { Settings, Contrast } from "lucide-react";
import { ImageEnhancementLevel } from "@/pages/home";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface EnhancementToolbarProps {
  enhancementLevel: ImageEnhancementLevel;
  onEnhancementLevelChange: (level: ImageEnhancementLevel) => void;
}

export default function EnhancementToolbar({ 
  enhancementLevel, 
  onEnhancementLevelChange 
}: EnhancementToolbarProps) {
  const enhancementOptions = [
    { value: 'none', label: 'None', description: 'Original image' },
    { value: 'light', label: 'Light', description: 'Minimal enhancement' },
    { value: 'medium', label: 'Medium', description: 'Balanced enhancement' },
    { value: 'strong', label: 'Strong', description: 'Maximum enhancement' }
  ] as const;

  const getCurrentOption = () => {
    return enhancementOptions.find(option => option.value === enhancementLevel);
  };

  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-4">
      <div className="flex items-center justify-between">
        {/* Toolbar Title */}
        <div className="flex items-center space-x-3">
          <div className="p-2 bg-primary-100 dark:bg-primary-900 rounded-lg">
            <Settings className="w-4 h-4 text-primary-600 dark:text-primary-400" />
          </div>
          <div>
            <h3 className="text-sm font-semibold text-gray-900 dark:text-white">
              Image Enhancement
            </h3>
            <p className="text-xs text-gray-500 dark:text-gray-400">
              Optimize text recognition for difficult images
            </p>
          </div>
        </div>

        {/* Enhancement Controls */}
        <div className="flex items-center space-x-4">
          {/* Contrast Enhancement Dropdown */}
          <div className="flex items-center space-x-2">
            <Contrast className="w-4 h-4 text-gray-500 dark:text-gray-400" />
            <div className="flex flex-col">
              <label className="text-xs font-medium text-gray-700 dark:text-gray-300 mb-1">
                Contrast Enhancement
              </label>
              <Select
                value={enhancementLevel}
                onValueChange={(value: ImageEnhancementLevel) => onEnhancementLevelChange(value)}
              >
                <SelectTrigger className="w-32 h-8 text-sm">
                  <SelectValue>
                    <span className="font-medium">{getCurrentOption()?.label}</span>
                  </SelectValue>
                </SelectTrigger>
                <SelectContent>
                  {enhancementOptions.map((option) => (
                    <SelectItem key={option.value} value={option.value}>
                      <div className="flex flex-col">
                        <span className="font-medium">{option.label}</span>
                        <span className="text-xs text-gray-500">{option.description}</span>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Future enhancement controls can be added here */}
          <div className="h-8 w-px bg-gray-200 dark:bg-gray-600"></div>
          
          {/* Placeholder for future enhancements */}
          <div className="text-xs text-gray-400 dark:text-gray-500 italic">
            More enhancements coming soon...
          </div>
        </div>
      </div>
    </div>
  );
}